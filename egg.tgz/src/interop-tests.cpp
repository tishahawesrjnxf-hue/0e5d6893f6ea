// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("interop tests\n", stdout);
  return lionss_run_workload("interop-tests");
}
