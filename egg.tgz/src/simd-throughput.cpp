// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("simd throughput\n", stdout);
  return lionss_run_workload("simd-throughput");
}
