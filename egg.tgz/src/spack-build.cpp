// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("spack build\n", stdout);
  return lionss_run_workload("spack-build");
}
